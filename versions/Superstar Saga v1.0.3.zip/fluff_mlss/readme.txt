Mario & Luigi: Superstar Saga Styled Balloon

This balloon is not part of a Ghost/Ukagaka.

-------- Version History --------

 Version 1.0.0 (5/20/2018)
   - Official Release

 Version 1.0.1 (2/5/2021)
   - Minor tweaks
   - added the necessary font...

 Version 1.0.2 (2/18/2021)
   - Removed font for individual download.
   - Added site source link.
   - Removed empty profile folder.
   - Minor coding and comment tweaks.

 Version 1.0.3 (5/19/2021)
   - Fixed the link to my site.